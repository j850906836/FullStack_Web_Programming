# HW1: Listicle

Please complete two webpages:
- Modify **listicle.html** and **css/listicle-style.css** to replicate the "On-campus Beverages" article that we provided as accurately as you can.
- Modify **my-list.html** and **css/my-list-style.css** to create your own list article and style it however you'd like!

See the [Homework 1 spec](https://fullstackccu.github.io/homeworks/1-listicle.html) for more detail and turn-in link.
