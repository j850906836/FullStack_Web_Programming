# HW3: Flashcards

This is the starter code for HW3: Flashcards. There is a fair amount of starter code this time around, so please [check out the spec](https://fullstackccu.github.io/homeworks/3-flashcards.html) for an explanation of the files.
